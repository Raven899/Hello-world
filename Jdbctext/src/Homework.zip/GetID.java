package Homework;

public class GetID {
	private String ID;

	public GetID() {
		super();
	}

	public GetID(String iD) {
		super();
		ID = iD;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	
}
